#define VERSION PACKAGE_VERSION" Apr-12-2015"
#define PGM PACKAGE_NAME
#define URL "http://sarg.sourceforge.net"
