<?php

system("sarg -r");

?>
